<?php
/**
* 
*/
class Registrationmodel extends CI_Model
{
	 
	function __construct()
	{
		parent::__construct();
		$this->tableName = 'registration';
	}

	public function insert($data= array())
	{
		$this->db->insert($this->tableName,$data);
	}
	public function select()
	{
		$this->db->select('*');
		$this->db->from($this->tableName);
		$query = $this->db->get();
		return $query->result();
	}
	public function selectdata($getId)
	{
		$this->db->select('*');
		$this->db->from('registration');
		$this->db->Where('id',$getId);
		$query = $this->db->get();
 
        return $query->result();
	}
}

?>