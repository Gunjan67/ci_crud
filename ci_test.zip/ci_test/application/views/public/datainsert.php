<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CodeIgniter Framework with AJAX and Bootstrap</title>
    <link href="<?php echo site_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  
 
  <div class="container">
    <h1> CodeIgniter Framework with AJAX and Bootstrap</h1>
</center>
    
    <button class="btn btn-success" onclick="add_book()"><i class="glyphicon glyphicon-plus"></i> Add Registration</button>
    <br />
    <br />
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Password</th>
          <th>Date Of Birth</th>
          <th>Images</th>
 
          <th style="width:125px;">Action
          </p></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($registration as  $value) : ?>
      <tr>
          <td><?= $value->name?></td>
          <td><?= $value->email?></td>
          <td><?= $value->password?></td>
          <td><?= $value->dob?></td>
          <td><img src="<?= $value->dob?>"></td>
                <td>
                  <button class="btn btn-warning" onclick="edit(<?= $value->id?>)"><i class="glyphicon glyphicon-pencil"></i></button>
                  <button class="btn btn-danger" ><i class="glyphicon glyphicon-remove"></i></button>
                </td>
      </tr>
        <?php endforeach?>

            
      </tbody>
     
    </table>
 
  </div>
 
  <script src="<?php echo site_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo site_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo site_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo site_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
 
 
  <script type="text/javascript">
    $(document).ready( function (){
      $('#table_id').DataTable();
    });
    var save_method; //for save method string
    var table;
 
    function add_book()
    {
      // save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }
    
    function edit(id)
    {
      // alert(id);
       $('#form_update')[0].reset(); // reset form on modals
       $('#modal_update_form').modal('show');
      var getValue = id;
      var url = "<?= site_url('crud/updatedata')?>";
      $.ajax({
        url:url,
        type:'POST',
        data:{id:getValue},
        dataType: "JSON",
        success:function (data) {
         $("#getid").val(data[0].id);
         $("#name").val(data[0].name);
         $("#email").val(data[0].email);
         $("#password").val(data[0].password);
         $("#dob").val(data[0].dob);
        }
      });
    }
   
  </script>
 
   <script type="text/javascript">
  $(document).ready(function(){
        $("#btnSave").click(function(){
          var url = "<?php echo site_url('registration/insertdata')?>";
          var data = $('#form').serialize();

          $.ajax({
            url:url,
            type: 'POST',
            data:data,
            success: function (data) {
                  alert(data);
                   $('#modal_form').modal('hide');
              location.reload();// for reload a page
                   }
            });
            
        });
            });    
  </script>
  <script type="text/javascript">
    $(document).ready(function()
    {
      $('#btnUpdate').click(function()
      {
        var url = "<?= site_url('crud/updateprocess')?>"
        var getData = $('#form_update').serialize();
        alert(getData);
      });
    });

  </script>
  
  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Registration Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" method="" enctype="multipart/form-data" id="form" class="form-horizontal">
         
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-3">Name</label>
              <div class="col-md-9">
                <input name="name" placeholder="Name" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Email</label>
              <div class="col-md-9">
                <input name="email" placeholder="Email" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">password</label>
              <div class="col-md-9">
                <input name="password" placeholder="Password" class="form-control" type="password">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Date of Birth</label>
              <div class="col-md-9">
                <input name="dob" placeholder="Date of Birth" class="form-control" type="date">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Photo</label>
              <div class="col-md-9">
                <input name="photo" placeholder="Photo" class="form-control" type="file">
              </div>
            </div>
 
          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave"  class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
 

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_update_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Registration Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" method="" enctype="multipart/form-data" id="form_update" class="form-horizontal">
         
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-3">Name</label>
              <div class="col-md-9">
                <input name="getid" placeholder="Name" id="getid" class="form-control" type="hidden">
                <input name="name" placeholder="Name" id="name" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Email</label>
              <div class="col-md-9">
                <input name="email" placeholder="Email" class="form-control" id="email" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">password</label>
              <div class="col-md-9">
                <input name="password" placeholder="Password" class="form-control" id="password" type="password">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Date of Birth</label>
              <div class="col-md-9">
                <input name="dob" placeholder="Date of Birth" class="form-control" id="dob" type="date">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Photo</label>
              <div class="col-md-9">
                <input name="photo" placeholder="Photo" class="form-control" type="file">
              </div>
            </div>
 
          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnUpdate"  class="btn btn-primary">Update</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  </body>
</html>