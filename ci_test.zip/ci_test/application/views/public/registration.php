<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CodeIgniter Framework with AJAX and Bootstrap</title>
    <link href="<?php echo site_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo site_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script>
  </head>
  <body>
 
 
  <div class="container">
    <h1> CodeIgniter Framework with registration</h1>
</center>

 



       <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title">Registration Form</h3>
      </div>
      <div class="modal-body form">
        <form action="#" method="" enctype="multipart/form-data" id="form" class="form-horizontal">
         
          <div class="form-body">
            <div class="form-group">
              <label class="control-label col-md-3">Name</label>
              <div class="col-md-9">
                <input name="name" placeholder="Name" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Email</label>
              <div class="col-md-9">
                <input name="email" placeholder="Email" class="form-control" type="text">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">password</label>
              <div class="col-md-9">
                <input name="password" placeholder="Password" class="form-control" type="password">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Date of Birth</label>
              <div class="col-md-9">
                <input name="dob" placeholder="Date of Birth" class="form-control" type="date">
 
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3">Photo</label>
              <div class="col-md-9">
                <input name="photo" placeholder="Photo" class="form-control" type="file">
              </div>
            </div>
 
          </div>
        </form>
          </div>
          <div class="modal-footer">
            <button type="button" id="btnSave"  class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
          </div>
        </div><!-- /.modal-content -->
  </div>
  <script type="text/javascript">
  $(document).ready(function(){
        $("#btnSave").click(function(){
          var url = "<?php echo site_url('registration/insertdata')?>";
          var data = $('#form').serialize();

            $.ajax({
                url:url,
                type: 'POST',
                data:data,
                success: function (data) {
                  alert(data);
                                }
            });
            
        });
            });    
  </script>
 
  <script src="<?php echo site_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo site_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo site_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo site_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
 
 
  </body>
</html>