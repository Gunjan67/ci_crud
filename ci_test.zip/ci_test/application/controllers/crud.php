<?php
/**
* 
*/
class Crud extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model("public/registrationmodel");
	}
	public function index()
	{
		$data['registration'] = $this->registrationmodel->select();
		$data['select'] = $this->registrationmodel->selectdata(1);
		$this->load->view('public/datainsert',$data);

	}
	public function updatedata()
	{
		$getId=  $this->input->post('id');
		$data =$this->registrationmodel->selectdata($getId);
		echo json_encode($data);
	}

	public function updateprocess()
	{
				if(!empty($_FILES['driver_aadhar']['name']))
        {
            $config['upload_path'] = 'uploads/images/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['file_name'] = $_FILES['driver_aadhar']['name'];
            
            //Load upload library and initialize configuration
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            
            if($this->upload->do_upload('driver_aadhar'))
            {
                $uploadData = $this->upload->data();
                $driver_aadhar = $uploadData['file_name'];
            }
            else
            {
                $driver_aadhar = '';
            }
        }
        else 
        {
            $driver_aadhar = '';
        }

	}

	
}

?>