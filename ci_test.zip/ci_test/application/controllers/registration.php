<?php
/**
* 
*/
class Registration extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('public/registrationmodel');
	}

	public function index()
	{
		$this->load->view('public/registration');
	}

	public function insertdata()
	{
		$arrayData = array('name' => 		$this->input->post('name'),
							'email' => 		$this->input->post('email'),
							'password' => md5($this->input->post('password')),
							'dob' => $this->input->post('dob') );
		$data = $this->registrationmodel->insert($arrayData);
		if(!$data)
		{ 
			echo "Data Insert Successfully";
		}
		else
		{
			echo "Data Failed";
		}
	}

	
}

?>